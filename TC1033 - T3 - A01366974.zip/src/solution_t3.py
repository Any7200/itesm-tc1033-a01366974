#A01366974 ANA LAURA RODRIGUEZ JURADO
#-*- coding:utf-8 -*-
import math
from airportDP import *

if __name__ == '__main__':
	empty_airport = Airport()
	populate_airport = AirportAD()
	#print(populate_airport.read_pilots_file()) #ya
	#print(populate_airport.read_passengers_file())#ya
